# Telegram Userbot

Este es un userbot para gestionar solicitudes en Telegram.

## Instalación y Configuración

1. Instalar dependencias:
   ```sh
   pip install -r requirements.txt
   ```

2. Iniciar la base de datos:
   ```sh
   python db.py
   ```

3. Ejecutar el bot:
   ```sh
   bash start.sh
   ```
