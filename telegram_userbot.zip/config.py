API_ID = 23047044
API_HASH = "2efd6bb57df5d0ef23b978825fe2b50e"
DB_URL = "postgresql://BotBuscar_owner:npg_sz3F6DSeWyAV@ep-lingering-base-a9cvujqb-pooler.gwc.azure.neon.tech/BotBuscar?sslmode=require"
CHAT_ID = -1001918569531
CHANNELS = ["https://t.me/c/1918569531/152167", "https://t.me/c/1918569531/152839"]
